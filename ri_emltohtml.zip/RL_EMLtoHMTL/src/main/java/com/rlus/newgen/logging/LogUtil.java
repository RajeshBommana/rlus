package com.rlus.newgen.logging;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.core.LoggerContext;

import com.rlus.utils.CustomMessage;

public class LogUtil {
	private static final Logger logger = LogManager.getLogger(LogUtil.class);
	private static String cabinetName;

	public static String getCabinetName() {
		return cabinetName;
	}

	public static void setCabinetName(String cabinetName) {
		LogUtil.cabinetName = cabinetName;
	}

	private LogUtil() {
		throw new IllegalStateException("Utility class");
	}

	public static void printLog(String msg, String level, String sResourceName) {
		try {
			LoggerContext context = (LoggerContext) LogManager.getContext(false);
			File file = new File(String.valueOf(System.getProperty("user.dir")) + File.separator + "log4j2.xml");
			context.setConfigLocation(file.toURI());
			HashMap<String, String> msgMap = new HashMap<>();
			String sXCorrelationId = UUID.randomUUID().toString();
			msgMap.put("correlationId", sXCorrelationId);
			msgMap.put("message", msg);
			Date date = new Date();
			String timeFormatString = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
			DateFormat timeFormat = new SimpleDateFormat(timeFormatString);
			String currentDateTime = timeFormat.format(date);
			msgMap.put("timestamp", currentDateTime);
			msgMap.put("resourceName", sResourceName);
			msgMap.put("environment", getCabinetName());
			msgMap.put("xTransactionId", sXCorrelationId);
			msgMap.put("hostname", "RL_EMLtoHTML");
			msgMap.put("logsource", "newgen");
			msgMap.put("logtype", "api");
			msgMap.put("priority", level);
			ThreadContext.put("CorrelationID", "correlationId:" + sXCorrelationId);
			if (level.equalsIgnoreCase("info"))
				logger.info(new CustomMessage(msgMap));
			if (level.equalsIgnoreCase("debug"))
				logger.debug(new CustomMessage(msgMap));
			if (level.equalsIgnoreCase("error"))
				logger.error(new CustomMessage(msgMap));
		} catch (Exception e) {
			System.out.println("Error in printLog" + e.getMessage());
		}
	}

}
