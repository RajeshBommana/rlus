package com.rlus.newgen.xml;

import java.io.File;
import java.io.IOException;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import com.rlus.newgen.logging.LogUtil;
import com.rlus.utils.Constants;
import com.rlus.utils.HttpClientManager;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class ODRestServices {

	static {
		try {
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, new TrustManager[] { new TrustManager() }, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(new AllowAllHostnameVerifier());
		} catch (Exception e) {
			throw new RuntimeException("Ignore Certificates failed", e);
		}
	}

	public String userName;
	public String userPassword;
	public String cabinetName;
	public String siteId;
	public String volumeId;
	public String restURL;
	public String i_userDBId;
	public String dataclassIndex;
	public String dataclassName;
	public String ccmUserDBId;
	public String strVersion;

	public String getI_userDBId() {
		return i_userDBId;
	}

	public void setI_userDBId(String i_userDBId) {
		this.i_userDBId = i_userDBId;
	}

	public String getCcmUserDBId() {
		return ccmUserDBId;
	}

	public void setCcmUserDBId(String ccmUserDBId) {
		this.ccmUserDBId = ccmUserDBId;
	}

	public String getStrVersion() {
		return strVersion;
	}

	public void setStrVersion(String strVersion) {
		this.strVersion = strVersion;
	}

	public String getDataclassIndex() {
		return dataclassIndex;
	}

	public void setDataclassIndex(String dataclassIndex) {
		this.dataclassIndex = dataclassIndex;
	}

	public String getDataclassName() {
		return dataclassName;
	}

	public void setDataclassName(String dataclassName) {
		this.dataclassName = dataclassName;
	}

	public ODRestServices() {
		super();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getCabinetName() {
		return cabinetName;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getVolumeId() {
		return volumeId;
	}

	public void setVolumeId(String volumeId) {
		this.volumeId = volumeId;
	}

	public void setCabinetName(String cabinetName) {
		this.cabinetName = cabinetName;
	}

	public String getRestURL() {
		return restURL;
	}

	public void setRestURL(String restURL) {
		this.restURL = restURL;
	}

	public String getUserDBId() {
		return i_userDBId;
	}

	public void setUserDBId(String userDBId) {
		this.i_userDBId = userDBId;
	}

	public boolean isConnected() {
		return i_userDBId != null;
	}

	public String connect() throws Exception {
		JSONObject jResponse = service(new StringBuilder()
				.append("{\"NGOExecuteAPIBDO\":{\"inputData\":{\"NGOConnectCabinet_Input\":")
				.append("{\"Option\":\"NGOConnectCabinet\",\"UserExist\":\"N\",\"CabinetName\":\"").append(cabinetName)
				.append("\",\"UserName\":\"").append(userName).append("\",\"UserPassword\":\"").append(userPassword)
				.append("\",\"locale\":\"en_US\",\"ApplicationInfo\":\"RL_ProcessAutoEmail\",\"ApplicationName\":\"RL_ProcessAutoEmail\"}},\"base64Encoded\":\"N\",\"locale\":\"en_US\"}}")
				.toString());
		try {
			i_userDBId = ((JSONObject) ((JSONObject) ((JSONObject) jResponse.get("NGOExecuteAPIResponseBDO"))
					.get("outputData")).get("NGOConnectCabinet_Output")).get("UserDBId").toString();
			LogUtil.printLog("UserDbId  : " + i_userDBId, "INFO", "connect");
			setUserDBId(i_userDBId);
			return i_userDBId;
		} catch (NullPointerException e) {
//			throw new Exception("Connect Failed");
			LogUtil.printLog("Error during OD connect: " + e.getMessage(), "ERROR", "connect");
			return "";
		}
	}

	public JSONObject disconnect() throws Exception {
		JSONObject jResponse = service(new StringBuilder().append(
				"{\"NGOExecuteAPIBDO\":{\"inputData\":{\"NGODisconnectCabinet_Input\":{\"Option\":\"NGODisconnectCabinet\",\"CabinetName\":\"")
				.append(cabinetName).append("\",\"UserDBId\":\"").append(i_userDBId)
				.append("\"}},\"base64Encoded\":\"N\",\"locale\":\"en_US\"}}").toString());
		i_userDBId = null;
		return jResponse;

	}

	protected JSONObject service(Object requestEntity) throws Exception {
		return service(requestEntity, "executeAPIJSON", "application/json;charset=UTF-8");
	}

	protected JSONObject service(String option, String otherInputs) throws Exception {
		return service(new StringBuilder().append("{\"NGOExecuteAPIBDO\":{\"inputData\":{\"").append(option)
				.append("_Input\":{\"Option\":\"").append(option).append("\",\"CabinetName\":\"").append(cabinetName)
				.append("\",\"UserDBId\":\"").append(i_userDBId).append("\",").append(otherInputs).append("}}}}")
				.toString());
	}

	protected JSONObject service(Object requestEntity, String service, String contentType) throws Exception {
		String jsonRequest = requestEntity.toString();

		RequestBody body = RequestBody.create(MediaType.parse(contentType), jsonRequest);
		Request request = new Request.Builder().url(restURL + service).method("POST", body)
				.addHeader("Content-Type", contentType).build();

		try (Response response = HttpClientManager.getInstance().getClient().newCall(request).execute()) {
			if (response.code() == 200) {
				try (ResponseBody responseBody = response.body()) {
					if (responseBody != null) {
						String responseStr = responseBody.string();
						if (responseStr != null && !responseStr.trim().isEmpty()) {
							removeDocContent(responseStr);
							return (JSONObject) new JSONParser().parse(responseStr);
						}
					}
				}
			}
			throw new Exception("WS Call Failed with status " + response.code());
		} catch (Exception e) {
			LogUtil.printLog("WS Call failed: " + e.getMessage(), Constants.ERROR, "service");
			throw e;
		}
	}

	protected static String removeDocContent(String response) {
		int index = response.indexOf("\"docContent\":");
		if (index != -1) {
			index += 15;
			StringBuilder sb = new StringBuilder().append(response.substring(0, index));
			response = response.substring(index);
			response = sb.append("X").append(response.substring(response.indexOf('"'))).toString();
		}
		return response;
	}

	public String uploadHTMLwithDataclass(File file, String parentFolderIndex, String dataclassFields, String comment) {
		String docUploadstatus = "";
		String json = new StringBuilder().append("{\"NGOAddDocumentBDO\":{\"cabinetName\":\"").append(cabinetName)
				.append("\",\"UserDBId\":\"").append(i_userDBId).append("\",\"folderIndex\":\"")
				.append(parentFolderIndex).append("\",\"documentName\":\"").append(file.getName())
				.append("\",\"volumeId\":\"").append(volumeId).append("\",\"Comment\":\"").append(comment)
				.append("\",\"accessType\":\"I\",\"createdByAppName\":\"html\",\"NGOAddDocDataDefCriterionBDO\": {\"dataDefIndex\":\"")
				.append(dataclassIndex).append("\",\"dataDefName\":\"").append(dataclassName)
				.append("\",\"NGOAddDocDataDefCriteriaDataBDO\":").append(dataclassFields).append("}}}").toString();
		LogUtil.printLog("Upload HTML Document with Dataclass Input " + json, Constants.INFO, "ODRESTSERVICE");

		// Build request outside try block for better error handling
		Request request = new Request.Builder().url(restURL.concat("addDocumentJSON"))
				.method("POST",
						new MultipartBody.Builder().setType(MultipartBody.FORM)
								.addFormDataPart("file", file.getName(),
										RequestBody.create(MediaType.parse("application/octet-stream"), file))
								.addFormDataPart("NGOAddDocumentBDO", json).build())
				.addHeader("Content-Type", "application/octet-stream").build();

		// Use shared HTTP client with proper resource management
		try (Response response = HttpClientManager.getInstance().getClient().newCall(request).execute()) {
			int statusCode = response.code();
			if (statusCode == 200) {
				// Properly manage response body with nested try-with-resources
				try (ResponseBody responseBody = response.body()) {
					if (responseBody != null) {
						json = responseBody.string();
						JSONObject obj = (JSONObject) new JSONParser().parse(json);
						JSONObject ngoAddDocumentResponseBdo = (JSONObject) obj.get("NGOAddDocumentResponseBDO");
						String status = (String) ngoAddDocumentResponseBdo.get("status");

						if ("0".equalsIgnoreCase(status)) {
							docUploadstatus = "success";
						} else {
							LogUtil.printLog("Upload failed - Response: " + json, Constants.ERROR, "ODRESTSERVICE");
							docUploadstatus = "failed";
						}
						LogUtil.printLog("Upload Status: " + status + ", Result: " + docUploadstatus, Constants.INFO,
								"ODRESTSERVICE");
					} else {
						LogUtil.printLog("Upload failed: Empty response body", Constants.ERROR, "ODRESTSERVICE");
						docUploadstatus = "failed";
					}
				}
			} else {
				LogUtil.printLog("Upload failed with HTTP status: " + statusCode, Constants.ERROR, "ODRESTSERVICE");
				docUploadstatus = "failed";
			}
		} catch (IOException e) {
			LogUtil.printLog("IOException during HTML upload: " + e.getMessage(), Constants.ERROR, "ODRESTSERVICE");
			docUploadstatus = "failed";
		} catch (org.json.simple.parser.ParseException e) {
			LogUtil.printLog("JSON parsing failed during HTML upload: " + e.getMessage(), Constants.ERROR,
					"ODRESTSERVICE");
			docUploadstatus = "failed";
		} catch (Exception e) {
			LogUtil.printLog("Unexpected error during HTML upload: " + e.getMessage(), Constants.ERROR,
					"ODRESTSERVICE");
			docUploadstatus = "failed";
		}

		return docUploadstatus;
	}

	public boolean validateUserForSession(String sessionID) {
		boolean activeFlag = false;
		try {
			JSONObject jResponse = service(new StringBuilder()
					.append("{\"NGOExecuteAPIBDO\":{\"inputData\":{\"NGOValidateUserForSession_Input\":")
					.append("{\"Option\":\"NGOValidateUserForSession\",\"CabinetName\":\"").append(cabinetName)
					.append("\",\"userDBId\":\"").append(sessionID).append("\",\"Password\":\"").append(userPassword)
					.append("\"}},\"base64Encoded\":\"N\",\"locale\":\"en_US\"}}").toString());
			String status = ((JSONObject) ((JSONObject) ((JSONObject) jResponse.get("NGOExecuteAPIResponseBDO"))
					.get("outputData")).get("NGOValidateUserForSession_Output")).get("Status").toString();
			if ("0".equalsIgnoreCase(status)) {
				activeFlag = true;
			}
		} catch (Exception e) {
			LogUtil.printLog("Validation Failed UserSession  : " + sessionID, "INFO", "ValidateSession");
		}
		return activeFlag;
	}

	public JSONObject SearchDocument(String FolderID, String noOfRecordsToFetch, String startFrom) throws Exception {

		return service("NGOSearchDocumentExt",
				new StringBuilder().append("\"LookInFolder\":").append(FolderID).append(",\"DataAlsoFlag\":\"")
						.append("Y").append("\",\"IncludeSubFolder\":\"").append("N").append("\",\"StartFrom\":\"")
						.append(startFrom).append("\",\"NoOfRecordsToFetch\":\"").append(noOfRecordsToFetch)
						.append("\",\"OrderBy\":\"")
						// .append("\",\"CreationDateRange\":\"BETWEEN,2021-02-27 00:00:00,2030-02-28
						// 23:59:59")
						.append("2").append("\",\"MaximumHitCountFlag\":\"").append("N").append("\"").toString());
	}

	public ArrayList<Object> getDocument(String docIndex) throws Exception {
		if (!validateUserForSession(i_userDBId))
			connect();
		try {

			JSONObject serviceResponse = service(
					new StringBuilder().append("{\"NGOGetDocumentBDO\":{\"cabinetName\":\"").append(cabinetName)
							.append("\",\"docIndex\":\"").append(docIndex).append("\",\"siteId\":\"").append(siteId)
							.append("\",\"volumeId\":\"").append(volumeId).append("\",\"userDBId\":\"")
							.append(i_userDBId)
							.append("\",\"locale\":\"en_US\",\"passAlgoType\":\"\",\"encrFlag\":\"\"}}").toString(),
					"getDocumentJSON", "application/json;charset=UTF-8");

			if (serviceResponse == null) {
				throw new Exception("Service returned null response");
			}

			JSONObject jsonObj = (JSONObject) serviceResponse.get("NGOGetDocumentBDOResponse");
			if (jsonObj == null) {
				throw new Exception("NGOGetDocumentBDOResponse not found in response");
			}

			ArrayList<Object> list = new ArrayList<>();
			list.add((String) jsonObj.get("createdByAppName"));
			list.add((String) jsonObj.get("docContent"));
			list.add((String) jsonObj.get("documentName"));
			list.add((String) jsonObj.get("documentSize"));
			list.add((String) jsonObj.get("documentType"));

			return list;

		} catch (Exception e) {
			LogUtil.printLog("Error fetching document " + docIndex + ": " + e.getMessage(), Constants.ERROR,
					"getDocument");
			throw e;
		}
	}

	public JSONObject get_MoveDocument(String sDestinationFolder, String sSourceFolder, String sDocId)
			throws Exception {
		try {
			return service("NGOMoveDocumentExt",
					(new StringBuilder().append("\"DestFolderIndex\":").append("\"" + sDestinationFolder + "\"")
							.append(",\"Documents\":{\"Document\":{\"DocumentIndex\":\"").append(sDocId)
							.append("\",\"ParentFolderIndex\":").append("\"" + sSourceFolder + "\"").append("} } }"))
							.toString());
		} catch (Exception e) {
			LogUtil.printLog("Failed to move document " + sDocId + " from " + sSourceFolder + " to "
					+ sDestinationFolder + ": " + e.getMessage(), Constants.ERROR, "get_MoveDocument");
			throw e;
		}
	}

}

class TrustManager implements X509TrustManager {

	@Override
	public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
	}

	@Override
	public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
	}

	@Override
	public X509Certificate[] getAcceptedIssuers() {
		return new X509Certificate[0];
	}

}

class AllowAllHostnameVerifier implements HostnameVerifier {

	@Override
	public boolean verify(String urlHostName, SSLSession session) {
		return true;
	}

}
