package com.rlus.newgen;

import com.rlus.newgen.logging.LogUtil;
import com.rlus.utils.AppConfig;
import com.rlus.utils.Constants;
import com.rlus.utils.CustomMessage;
import com.rlus.utils.ProcessHTMLtoEML;

public class StartServer {
	ProcessHTMLtoEML processHTMLtoEML = null;
	Thread t1;

	public StartServer() {
		try {
			startFunction();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static void main(String[] args) {
		try {
			AppConfig.Init();
			new StartServer();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void startFunction() {

		try {
			LogUtil.setCabinetName(AppConfig.getProperty("jtsCabinet"));
			LogUtil.printLog("Process startFunction Thread started", Constants.INFO, Constants.CMDSTART);
			this.processHTMLtoEML = new ProcessHTMLtoEML();
			this.t1 = new Thread(this.processHTMLtoEML);
			this.t1.setName("Process processHTMLtoEML");
			this.t1.start();
		} catch (Exception exception1) {
			LogUtil.printLog("Error in Start Server : " + CustomMessage.stackTraceToString(exception1),
					Constants.ERROR, Constants.CMDSTART);
		}
	}
}