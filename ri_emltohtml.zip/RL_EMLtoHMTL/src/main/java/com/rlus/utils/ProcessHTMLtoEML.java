package com.rlus.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.rlus.newgen.logging.LogUtil;
import com.rlus.newgen.xml.ODRestServices;

import jakarta.mail.Address;
import jakarta.mail.BodyPart;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;
import jakarta.mail.Part;
import jakarta.mail.Session;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import org.apache.commons.codec.binary.Base64;
//import javax.mail.Address;
import jakarta.mail.internet.InternetAddress;

public class ProcessHTMLtoEML implements Runnable {
	protected static final ODRestServices ODRS = new ODRestServices();
	boolean bConnected = false;
	/** check **/
	DateFormat dateFormat = null;
	Date date = null;
	private static final Session EMAIL_SESSION = Session.getDefaultInstance(new Properties());
	private final static String PaginationBatchSize = AppConfig.getProperty("PaginationBatchSize");
	private final static String SearchFolderIndex = AppConfig.getProperty("SearchFolderIndex");
	private final static String EMLBaseDir = AppConfig.getProperty("BaseDir");
	private final static String EMLDownloadFolder = AppConfig.getProperty("DownloadFolder");
	private final static String SuccessFolderIndex = AppConfig.getProperty("SuccessFolderIndex");

	public ProcessHTMLtoEML() {

	}

	public void run() {
		AppConfig.Init();
		LogUtil.printLog(" Thread started ", Constants.INFO, Constants.ProcessHTMLtoEML);
		String sessionID = "";
		try {
			// Set ODRS properties
			String[] props = { "VERSION", "jtsCabinet", "jtsUserName", "jtsPassword", "siteId", "volumeID", "ODRestURL",
					"DataClassIndex", "DataClassName" };
			String[] methods = { "setStrVersion", "setCabinetName", "setUserName", "setUserPassword", "setSiteId",
					"setVolumeId", "setRestURL", "setDataclassIndex", "setDataclassName" };
			for (int i = 0; i < props.length; i++)
				ODRS.getClass().getMethod(methods[i], String.class).invoke(ODRS, AppConfig.getProperty(props[i]));

			sessionID = ODRS.connect();

			if (!"".equalsIgnoreCase(sessionID)) {
				bConnected = true;
				ODRS.setUserDBId(sessionID);
				// To be commented for Common processing of HTML conversions
				ProcessEmails(sessionID);
			}
			LogUtil.printLog("Thread ended with release version END ", Constants.INFO, Constants.ProcessHTMLtoEML);
		} catch (Exception e) {
			LogUtil.printLog("Error in connecting" + CustomMessage.stackTraceToString(e), Constants.ERROR,
					Constants.ProcessHTMLtoEML);
			Thread.currentThread().interrupt();
		} finally {
			try {

				if (bConnected) {
					ODRS.disconnect();
				}
			} catch (Exception e) {
				LogUtil.printLog("Error in Disconnecting " + CustomMessage.stackTraceToString(e), Constants.ERROR,
						Constants.ProcessHTMLtoEML);
			}
		}
		LogUtil.printLog("Returning from processWI function", Constants.INFO, Constants.ProcessHTMLtoEML);
	}

	private void ProcessEmails(String sessionID) {

		try {
			if (!ODRS.validateUserForSession(sessionID)) {
				sessionID = ODRS.connect();
				ODRS.setUserDBId(sessionID);
			}
			int pageNo = 1, batchSize = Integer.parseInt(PaginationBatchSize), startFrom = 1;
			while (true) {
				LogUtil.printLog("Fetching batch #" + pageNo, Constants.INFO, Constants.PROCESSEMAILS);
				Map<String, Map<String, String>> emlResultMap = rpaSearchBatch(SearchFolderIndex, batchSize, startFrom);
				if (emlResultMap == null || emlResultMap.isEmpty())
					break;
				for (Map.Entry<String, Map<String, String>> entry : emlResultMap.entrySet())
					convertSingleEmail(entry.getKey(), entry.getValue());
				pageNo++;
			}
		} catch (Exception e) {
			LogUtil.printLog("Error in processing emails: " + CustomMessage.stackTraceToString(e), Constants.ERROR,
					Constants.PROCESSEMAILS);
		}
	}

	private boolean convertSingleEmail(String docIndexKey, Map<String, String> fieldMap) {

		String downloadDir = EMLBaseDir + File.separator + EMLDownloadFolder;
		String[] docParts = docIndexKey.split("#", 3);
		String docIndex = docParts[0];
		String comment = docParts.length > 1 ? docParts[1] : "";
		String CreationDateTime = docParts[2];

		try {
			LogUtil.printLog("Processing Document with DocIndex " + docIndex, Constants.INFO, Constants.PROCESSEMAILS);

			String downloadedFileName = downloadDocument(docIndex, downloadDir);
			LogUtil.printLog("Downloaded document Name  " + downloadedFileName, Constants.INFO,
					Constants.PROCESSEMAILS);

			JSONArray dataList = new JSONArray();
			for (Map.Entry<String, String> entry : fieldMap.entrySet()) {
				String[] values = entry.getValue().split(",");
				if (values.length > 3 || "D".equalsIgnoreCase(values[2])) {
					JSONObject json = new JSONObject();
					json.put("indexId", values[1]);
					json.put("indexType", values[2]);
					json.put("indexValue",
							"D".equalsIgnoreCase(values[2])
									? ((values.length > 3 && values[3] != null && !values[3].trim().isEmpty())
											? decodeDate(values[3])
											: decodeDate(CreationDateTime))
									: values[3]);
					dataList.add(json);
				}
			}

			if (!downloadedFileName.isEmpty()) {
				File emlFile = new File(downloadDir, downloadedFileName);
				File htmlFile = new File(downloadDir, downloadedFileName.replaceAll(".eml", "") + ".html");
				boolean converted = convertEmlToHtml(emlFile, htmlFile);

				LogUtil.printLog("EML to HTML conversion status " + converted + " For document " + downloadedFileName,
						Constants.INFO, Constants.PROCESSEMAILS);

				if (converted) {
					String status = uploadHtmlWithRetry(htmlFile, dataList.toString(), comment);
					if ("success".equalsIgnoreCase(status)) {
						LogUtil.printLog("Initiate document Move for document  " + docIndex, Constants.INFO,
								Constants.PROCESSEMAILS);
						ODRS.get_MoveDocument(SuccessFolderIndex, SearchFolderIndex, docIndex);
					}
				}
			}
		} catch (Exception e) {
			LogUtil.printLog("Exception during convertSingle and Upload process of emails    "
					+ CustomMessage.stackTraceToString(e), Constants.INFO, Constants.PROCESSEMAILS);
			return false;
		}
		return true;
	}

	private String uploadHtmlWithRetry(File htmlFile, String dataList, String comment) {
		String status = ODRS.uploadHTMLwithDataclass(htmlFile, AppConfig.getProperty("FNWLImportFolderIndex"), dataList,
				comment);
		LogUtil.printLog(" Status of Uploading HTML after conversion   " + status, Constants.INFO,
				Constants.PROCESSEMAILS);
		if (!"success".equalsIgnoreCase(status)) {
			LogUtil.printLog(" Retry HTML upload  ", Constants.INFO, Constants.PROCESSEMAILS);
			status = ODRS.uploadHTMLwithDataclass(htmlFile, AppConfig.getProperty("FNWLImportFolderIndex"), dataList,
					comment);
			LogUtil.printLog(" Status of Uploading HTML after conversion   " + status, Constants.INFO,
					Constants.PROCESSEMAILS);
		}
		return status;
	}

	protected String getIndexId(JSONObject fieldArrayObject, int i) {
		String indexId = "";
		try {
			indexId = (String) fieldArrayObject.get("IndexId");
			if (StringUtils.isBlank(indexId) || "null".equalsIgnoreCase(indexId))
				indexId = "";
		} catch (Exception e) {
			LogUtil.printLog("Error in getting indexId " + e.getMessage(), Constants.ERROR, "getIndexId");
		}
		return indexId.trim();

	}

	protected String getIndexType(JSONObject fieldArrayObject, int i) {
		String indexType = "";
		try {
			indexType = (String) fieldArrayObject.get("IndexType");
			if (StringUtils.isBlank(indexType) || "null".equalsIgnoreCase(indexType))
				indexType = "";
		} catch (Exception e) {
			LogUtil.printLog("Error in getting indexType " + e.getMessage(), Constants.ERROR, "getIndexType");
		}
		return indexType.trim();

	}

	protected String getIndexValue(JSONObject fieldArrayObject, int i) {
		String indexValue = "";
		try {
			if (fieldArrayObject.get("IndexValue") instanceof Double)
				indexValue = String.valueOf((Double) fieldArrayObject.get("IndexValue"));
			else
				indexValue = (String) fieldArrayObject.get("IndexValue");

			if (StringUtils.isBlank(indexValue) || "null".equalsIgnoreCase(indexValue))
				indexValue = "";
		} catch (Exception e) {
			LogUtil.printLog("Error in getting IndexValue " + e.getMessage(), Constants.ERROR, "getIndexValue");
		}
		return indexValue.trim();

	}

	public static String decodeDate(String inputDate) {
		List<String> possibleFormats = Arrays.asList("yyyy-MM-dd HH:mm:ss.S", "yyyy-MM-dd HH:mm:ss", "MM/dd/yyyy",
				"yyyy/MM/dd", "dd/MM/yyyy", "yyyy-MM-dd", "dd MMM yyyy", "MMM dd, yyyy", "yyyyMMdd", "MM-dd-yyyy",
				"dd.MM.yyyy", "yyyy.MM.dd", "dd-MM-yyyy", "yyyy-MM-dd HH:mm:ss", "MM-dd-yyyy HH:mm:ss", "yyyyMMdd",
				"yyyy-MM-dd'T'HH:mm:ss", "MM/dd/yyyy HH:mm:ss", "dd-MM-yyyy");

		for (String format : possibleFormats) {
			try {
				DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(format);
				LocalDate date = LocalDate.parse(inputDate, inputFormatter);
				return date.format(DateTimeFormatter.ISO_LOCAL_DATE); // "YYYY-MM-DD"
			} catch (DateTimeParseException e) {
//            	LogUtil.printLog("Invalid date format  : " + inputDate, "INFO", "DateFormatCheck");
			}
		}

		LogUtil.printLog("Unrecognized date format  : " + inputDate, "ERROR", "DateFormatCheck");
		return "";
	}

	public static String formatRecipients(Address[] recipients) {
		if (recipients == null || recipients.length == 0) {
			return "";
		}

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < recipients.length; i++) {
			if (i > 0)
				sb.append("; ");

			if (recipients[i] instanceof InternetAddress) {
				InternetAddress ia = (InternetAddress) recipients[i];
				String personal = ia.getPersonal();
				String email = ia.getAddress();

				if (personal != null && !personal.isEmpty()) {
					sb.append(personal).append(" <").append(email).append(">");
				} else {
					sb.append(email);
				}
			} else {
				sb.append(recipients[i].toString());
			}
		}
		return sb.toString();
	}

	public static boolean convertEmlToHtml(File emlFile, File outputHtmlFile) throws Exception {

		try {
			LogUtil.printLog("Starting EML to HTML conversion: " + emlFile.getName(), Constants.INFO,
					Constants.PROCESSEMAILS);
//			Session session = Session.getDefaultInstance(new Properties());

			try (FileInputStream is = new FileInputStream(emlFile)) {
				MimeMessage message = new MimeMessage(EMAIL_SESSION, is);

				EmailMetadata metadata = extractEmailMetadata(message);
				String htmlContent = buildHtmlContent(metadata, message);
				writeHtmlToFile(outputHtmlFile, htmlContent);

				LogUtil.printLog("Successfully converted EML to HTML: " + outputHtmlFile.getName(), Constants.INFO,
						Constants.PROCESSEMAILS);
				return true;
			}
		} catch (IOException e) {
			LogUtil.printLog("IO error during EML conversion: " + e.getMessage(), Constants.ERROR,
					Constants.PROCESSEMAILS);
			throw new Exception("Failed to read EML file: " + emlFile.getName(), e);

		} catch (MessagingException e) {
			LogUtil.printLog("Email parsing error during conversion: " + e.getMessage(), Constants.ERROR,
					Constants.PROCESSEMAILS);
			throw new Exception("Failed to parse EML file: " + emlFile.getName(), e);

		} catch (Exception e) {
			LogUtil.printLog("Unexpected error during EML conversion: " + e.getMessage(), Constants.ERROR,
					Constants.PROCESSEMAILS);
			throw new Exception("EML conversion failed for: " + emlFile.getName(), e);
		}

	}

	private static EmailMetadata extractEmailMetadata(MimeMessage message) throws MessagingException {
		try {
			String from = formatRecipients(message.getFrom());
			String to = formatRecipients(message.getRecipients(Message.RecipientType.TO));
			String cc = formatRecipients(message.getRecipients(Message.RecipientType.CC));
			String subject = message.getSubject();

			return new EmailMetadata(from, to, cc, subject);

		} catch (MessagingException e) {
			LogUtil.printLog("Error extracting email metadata: " + e.getMessage(), Constants.ERROR,
					Constants.PROCESSEMAILS);
			throw e;
		}
	}

	private static String buildHtmlContent(EmailMetadata metadata, MimeMessage message) throws Exception {
		StringBuilder html = new StringBuilder(1024); // Pre-allocate for performance

		buildHtmlHeader(html, metadata);

		Object content = message.getContent();
		if (content instanceof Multipart) {
			processMultipartContent(html, (Multipart) content);
		} else {
			// Simple text email
			html.append("<pre>").append(escapeHtml(content.toString())).append("</pre>");
		}

		html.append("</body></html>");
		return html.toString();
	}

	private static void buildHtmlHeader(StringBuilder html, EmailMetadata metadata) {
		html.append("<html><body>");
		html.append("<b>From:</b> ").append(escapeHtml(metadata.getFrom())).append("<br>");
		html.append("<b>To:</b> ").append(escapeHtml(metadata.getTo())).append("<br>");

		if (metadata.getCc() != null && !metadata.getCc().trim().isEmpty()) {
			html.append("<b>Cc:</b> ").append(escapeHtml(metadata.getCc())).append("<br>");
		}

		html.append("<b>Subject:</b> ").append(escapeHtml(metadata.getSubject())).append("<br><hr>");
	}

	private static void processMultipartContent(StringBuilder html, Multipart multipart) throws Exception {
		Map<String, String> cidMap = new HashMap<>();
		StringBuilder body = new StringBuilder();

		try {
			int partCount = multipart.getCount();

			for (int i = 0; i < partCount; i++) {
				BodyPart part = multipart.getBodyPart(i);

				if (isAttachmentOrImage(part)) {
					processImageAttachment(part, cidMap);
				} else if (part.isMimeType("text/html")) {
					body.append(part.getContent().toString());
				} else if (part.isMimeType("text/plain") && body.length() == 0) {
					body.append("<pre>").append(escapeHtml(part.getContent().toString())).append("</pre>");
				}
			}

			String htmlBody = replaceCidReferences(body.toString(), cidMap);
			html.append(htmlBody);

		} catch (MessagingException | IOException e) {
			LogUtil.printLog("Error processing multipart content: " + e.getMessage(), Constants.ERROR,
					Constants.PROCESSEMAILS);
			throw new Exception("Failed to process email content", e);
		}
	}

	private static void processImageAttachment(BodyPart part, Map<String, String> cidMap) throws Exception {
		try {
			MimeBodyPart imgPart = (MimeBodyPart) part;
			String cid = imgPart.getContentID();

			if (cid != null) {
				cid = cid.replaceAll("[<>]", "");

				try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
					imgPart.getDataHandler().writeTo(baos);

					String base64 = Base64.encodeBase64String(baos.toByteArray());
					String mimeType = imgPart.getContentType().split(";")[0];
					String dataUri = "data:" + mimeType + ";base64," + base64;

					cidMap.put(cid, dataUri);

					LogUtil.printLog("Processed image attachment with CID: " + cid, Constants.DEBUG,
							Constants.PROCESSEMAILS);
				}
			}
		} catch (Exception e) {
			LogUtil.printLog("Error processing image attachment: " + e.getMessage(), Constants.WARN,
					Constants.PROCESSEMAILS);
			// Continue processing other parts instead of failing completely
		}
	}

	private static void writeHtmlToFile(File outputHtmlFile, String htmlContent) throws IOException {
		try {
			File tempFile = new File(outputHtmlFile.getAbsolutePath() + ".tmp");

			Files.write(tempFile.toPath(), htmlContent.getBytes(StandardCharsets.UTF_8));
			if (Files.move(tempFile.toPath(), outputHtmlFile.toPath(), StandardCopyOption.REPLACE_EXISTING) == null) {
				throw new IOException("Failed to rename temp file to final output file");
			}

			LogUtil.printLog("HTML content written to: " + outputHtmlFile.getAbsolutePath(), Constants.DEBUG,
					Constants.PROCESSEMAILS);

		} catch (IOException e) {
			LogUtil.printLog("Error writing HTML to file: " + e.getMessage(), Constants.ERROR, Constants.PROCESSEMAILS);
			throw e;
		}
	}

	private static boolean isAttachmentOrImage(BodyPart part) throws MessagingException {
		return Part.ATTACHMENT.equalsIgnoreCase(part.getDisposition()) || part.isMimeType("image/*");
	}

	private static String replaceCidReferences(String htmlBody, Map<String, String> cidMap) {
		String result = htmlBody;
		for (Map.Entry<String, String> entry : cidMap.entrySet()) {
			result = result.replace("cid:" + entry.getKey(), entry.getValue());
		}
		return result;
	}

	private static String escapeHtml(String text) {
		if (text == null)
			return "";
		return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'",
				"&#x27;");
	}

	private static class EmailMetadata {
		private final String from;
		private final String to;
		private final String cc;
		private final String subject;

		public EmailMetadata(String from, String to, String cc, String subject) {
			this.from = from != null ? from : "";
			this.to = to != null ? to : "";
			this.cc = cc;
			this.subject = subject != null ? subject : "";
		}

		public String getFrom() {
			return from;
		}

		public String getTo() {
			return to;
		}

		public String getCc() {
			return cc;
		}

		public String getSubject() {
			return subject;
		}
	}

	private String downloadDocument(String docIndex, String downloadDir) {

		try {
			ArrayList<Object> list = ODRS.getDocument(docIndex);
			if (list == null || list.size() < 3)
				return "";
			String customDocName = list.get(2) + "." + list.get(0);
			File file = new File(downloadDir, customDocName);
			file.getParentFile().mkdirs();
			byte[] content = Base64.decodeBase64(String.valueOf(list.get(1)));
			if (content == null || content.length == 0)
				return "";
			try (FileOutputStream fos = new FileOutputStream(file)) {
				fos.write(content);
			}
			return customDocName;

		} catch (Exception ex) {
			LogUtil.printLog("Issues with download Email from ODRS " + CustomMessage.stackTraceToString(ex),
					Constants.ERROR, Constants.PROCESSEMAILS);
		}
		return "";

	}

	@SuppressWarnings("unchecked")
	private Map<String, Map<String, String>> rpaSearchBatch(String folderIdx, int batchSize, int startFrom) {
		Map<String, Map<String, String>> resultMap = new HashMap<>();
		JSONParser parser = new JSONParser();

		try {

			String strTotalNoOfRecords = "0";
			String strNoOfRecordsFetched = "0";

			JSONObject json = ODRS.SearchDocument(folderIdx, String.valueOf(batchSize), String.valueOf(startFrom));
			String strMainCode = ((JSONObject) ((JSONObject) ((JSONObject) json.get("NGOExecuteAPIResponseBDO"))
					.get("outputData")).get("NGOSearchDocumentExt_Output")).get("Status").toString();
			if (strMainCode.equals("0")) {
				strTotalNoOfRecords = (((JSONObject) ((JSONObject) ((JSONObject) json.get("NGOExecuteAPIResponseBDO"))
						.get("outputData")).get("NGOSearchDocumentExt_Output")).get("TotalNoOfRecords").toString());

				LogUtil.printLog("TotalNoOfRecords in the folder" + strTotalNoOfRecords, Constants.INFO,
						Constants.PROCESSEMAILS);

				strNoOfRecordsFetched = (((JSONObject) ((JSONObject) ((JSONObject) json.get("NGOExecuteAPIResponseBDO"))
						.get("outputData")).get("NGOSearchDocumentExt_Output")).get("NoOfRecordsFetched").toString());

				LogUtil.printLog("NoOfRecordsFetched in the folder" + strNoOfRecordsFetched, Constants.INFO,
						Constants.PROCESSEMAILS);

			}
			if (Integer.parseInt(strNoOfRecordsFetched) > 0) {
				JSONObject NGOExecuteAPIResponseBDO = (JSONObject) json.get("NGOExecuteAPIResponseBDO");
				JSONObject outputData = (JSONObject) NGOExecuteAPIResponseBDO.get("outputData");
				JSONObject NGOSearchDocumentExt_Output = (JSONObject) outputData.get("NGOSearchDocumentExt_Output");
				JSONObject SearchResults = (JSONObject) NGOSearchDocumentExt_Output.get("SearchResults");
				Object searchResultObj = SearchResults.get("SearchResult");
				JSONArray searchResult = new JSONArray();
				if (searchResultObj instanceof JSONArray) {
					searchResult = (JSONArray) searchResultObj;
				} else if (searchResultObj instanceof JSONObject) {
					JSONObject singleResult = (JSONObject) searchResultObj;
					// Wrap it in a JSONArray to handle uniformly
					searchResult.add(singleResult);
				}

				for (int i = 0; i < searchResult.size(); i++) {
					JSONObject jsonObj = (JSONObject) searchResult.get(i);
					JSONObject Document = (JSONObject) jsonObj.get("Document");
					Map<String, String> fieldMap = new HashMap<>();

					JSONObject dataDefinition = (JSONObject) parser.parse(Document.get("DataDefinition").toString());
					if (dataDefinition.containsKey("Fields")) {
						JSONObject fields = (JSONObject) parser.parse(dataDefinition.get("Fields").toString());

						if (fields.containsKey("Field")) {
							JSONArray fieldArray = (JSONArray) fields.get("Field");

							for (int j = 0; j < fieldArray.size(); j++) {

								JSONObject fieldObject = (JSONObject) parser.parse(fieldArray.get(j).toString());
								String indexName = (String) fieldObject.get("IndexName");

								String indexId = getIndexId(fieldObject, j);
								String indexType = getIndexType(fieldObject, j);
								String indexValue = getIndexValue(fieldObject, j);
								String fieldValues = indexName + "," + indexId + "," + indexType + "," + indexValue;
								fieldMap.put(indexId, fieldValues);

							}
						}
					}

					String docIndex = String.valueOf(Document.get("DocumentIndex"));
					String comment = String.valueOf(Document.get("Comment"));
					String CreationDateTime = String.valueOf(Document.get("CreationDateTime"));
					resultMap.put(docIndex + "#" + comment + "#" + CreationDateTime, fieldMap);
					// System.out.println("added " + docIndex);

				}
			}

		} catch (Exception e) {
			LogUtil.printLog("Error in batch search: " + CustomMessage.stackTraceToString(e), Constants.ERROR,
					Constants.PROCESSEMAILS);
		}

		return resultMap;
	}

}