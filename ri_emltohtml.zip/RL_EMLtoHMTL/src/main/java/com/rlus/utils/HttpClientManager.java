package com.rlus.utils;

import java.util.concurrent.TimeUnit;

import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import com.rlus.newgen.logging.LogUtil;

/**
 * Singleton HTTP Client Manager for efficient resource management
 * Provides a shared, properly configured OkHttpClient instance to prevent
 * resource leaks and improve performance through connection pooling.
 */
public class HttpClientManager {
    
    private static final HttpClientManager INSTANCE = new HttpClientManager();
    private final OkHttpClient httpClient;
    
    private HttpClientManager() {
        this.httpClient = createConfiguredClient();
        LogUtil.printLog("HttpClientManager initialized with connection pooling", 
                Constants.INFO, "HttpClientManager");
    }
    
    /**
     * Get the singleton instance
     */
    public static HttpClientManager getInstance() {
        return INSTANCE;
    }
    
    /**
     * Get the shared HTTP client instance
     */
    public OkHttpClient getClient() {
        return httpClient;
    }
    
    /**
     * Create a properly configured OkHttpClient
     */
    private OkHttpClient createConfiguredClient() {
        return new OkHttpClient.Builder()
            // Connection timeouts
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .connectTimeout(120, TimeUnit.SECONDS)
            
            // Connection pool configuration
            .connectionPool(new ConnectionPool(
                10,  // Maximum idle connections
                5,   // Keep alive duration  
                TimeUnit.MINUTES
            ))
            
            // Retry configuration
            .retryOnConnectionFailure(true)
            
            // Follow redirects
            .followRedirects(true)
            .followSslRedirects(true)
            
            .build();
    }
    
    /**
     * Shutdown the HTTP client and cleanup resources
     * Should be called during application shutdown
     */
    public void shutdown() {
        try {
            // Shutdown the dispatcher's executor service
            httpClient.dispatcher().executorService().shutdown();
            
            // Evict all connections from the connection pool
            httpClient.connectionPool().evictAll();
            
            LogUtil.printLog("HttpClientManager shutdown completed", 
                    Constants.INFO, "HttpClientManager");
        } catch (Exception e) {
            LogUtil.printLog("Error during HttpClientManager shutdown: " + e.getMessage(), 
                    Constants.ERROR, "HttpClientManager");
        }
    }
    
    /**
     * Get connection pool statistics for monitoring
     */
    public String getConnectionPoolStats() {
        ConnectionPool pool = httpClient.connectionPool();
        return String.format("ConnectionPool Stats - Idle: %d, Total: %d", 
                pool.idleConnectionCount(), pool.connectionCount());
    }
    
    /**
     * Check if the HTTP client is properly configured
     */
    public boolean isHealthy() {
        try {
            return httpClient != null && 
                   httpClient.connectionPool() != null &&
                   !httpClient.dispatcher().executorService().isShutdown();
        } catch (Exception e) {
            LogUtil.printLog("Health check failed: " + e.getMessage(), 
                    Constants.ERROR, "HttpClientManager");
            return false;
        }
    }
} 