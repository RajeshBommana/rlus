package com.rlus.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import com.rlus.newgen.logging.LogUtil;

public class AppConfig {

	public static final String PROPERTIES_DEFAULT = System.getProperty("user.dir") + File.separator
			+ "application.properties";
	private static Properties props;
	private static AppConfig appConfgInstance;

	public static AppConfig Init() {

		return Init(PROPERTIES_DEFAULT);
	}

	private AppConfig() {
	}

	private static class SingletonHelper {
		private static final AppConfig INSTANCE = new AppConfig();
	}

	private static AppConfig Init(String propertiesfile) {
		if (appConfgInstance == null) {
			appConfgInstance = SingletonHelper.INSTANCE;
			props = new Properties();
			try (FileInputStream fin = new FileInputStream(propertiesfile)) {
				props.load(fin);
				LogUtil.printLog("AppConfig Initialized", Constants.INFO, "AppConfig Init");
			} catch (IOException e) {
				LogUtil.printLog(e.toString(), Constants.ERROR, "AppConfig Init");
			}
		}
		return appConfgInstance;
	}

	public static String getProperty(String key) {

		if (appConfgInstance == null) {
			LogUtil.printLog("Properties not Initialized.  Run Init() first.", Constants.ERROR,
					"AppConfig getProperty");
			return "";
		}
		String retValue = props.getProperty(key);
		if (retValue == null) {
			LogUtil.printLog("No value found for key: " + key + ". Returning blank", Constants.ERROR,
					"AppConfig getProperty");
			retValue = "";
		}
		return retValue;
	}

}
